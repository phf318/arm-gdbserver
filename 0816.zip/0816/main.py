
import requests
import re
from bs4 import BeautifulSoup
import openpyxl

url = "https://www.dunkhome.com/tech/"
response = requests.get(url)

soup = BeautifulSoup(response.content, "html.parser")

menu_items = soup.find("div", {"data-kind": "outer"})

lines = str(menu_items).splitlines()

items = []
for line in lines:
    if len(line) > 5:
        match = re.search(r'>.*<', line)
        if match:
            name = match.group(0)[1:-1]
            items.append(name)

work = openpyxl.Workbook()

sheet = work.active
column = "A"

column2 = "H"
for index, item in enumerate(items, start=1):
    cell = f"{column}{index}"
    sheet[cell] = item


for index, item in enumerate(items, start=449):
    sub_menu_response = requests.get("https://www.dunkhome.com/tech/" + str(index))
    num = index-448
    sub_menu_soup = BeautifulSoup(sub_menu_response.content, "html.parser")
    sub_menu_text = sub_menu_soup.find("div", {"class": "s-detail tech-detail clearfix"})
    if sub_menu_text != None:
        cell = f"{column2}{num}"
        sheet[cell] = str(sub_menu_text.contents)


work.save("new.xlsx")